<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" dir="ltr">
  <head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="shortcut icon" href="/files/garland_favicon.png" type="image/x-icon" />
<!--[if lt IE 7]>
<script defer type="text/javascript" src="/files/pngfix.js"></script>
<![endif]-->
    <title>Open Source Initiative OSI - Common Development and Distribution License (CDDL-1.0) | Open Source Initiative</title>
    <link type="text/css" rel="stylesheet" media="all" href="/modules/aggregator/aggregator.css?V" />
<link type="text/css" rel="stylesheet" media="all" href="/modules/node/node.css?V" />
<link type="text/css" rel="stylesheet" media="all" href="/modules/system/defaults.css?V" />
<link type="text/css" rel="stylesheet" media="all" href="/modules/system/system.css?V" />
<link type="text/css" rel="stylesheet" media="all" href="/modules/system/system-menus.css?V" />
<link type="text/css" rel="stylesheet" media="all" href="/modules/user/user.css?V" />
<link type="text/css" rel="stylesheet" media="all" href="/sites/all/modules/mollom/mollom.css?V" />
<link type="text/css" rel="stylesheet" media="all" href="/modules/comment/comment.css?V" />
<link type="text/css" rel="stylesheet" media="all" href="/files/color/garland-4208c934/style.css?V" />
<link type="text/css" rel="stylesheet" media="print" href="/themes/garland/print.css?V" />
    <script type="text/javascript" src="/misc/jquery.js?V"></script>
<script type="text/javascript" src="/misc/drupal.js?V"></script>
<script type="text/javascript" src="/sites/all/modules/mollom/mollom.js?V"></script>
<script type="text/javascript">
<!--//--><![CDATA[//><!--
jQuery.extend(Drupal.settings, { "basePath": "/" });
//--><!]]>
</script>
    <!--[if lt IE 7]>
      <link type="text/css" rel="stylesheet" media="all" href="/themes/garland/fix-ie.css" />    <![endif]-->
  </head>
  <body class="sidebar-left">

<!-- Layout -->
  <div id="header-region" class="clear-block"></div>

    <div id="wrapper">
    <div id="container" class="clear-block">

      <div id="header">
        <div id="logo-floater">
        <h1><a href="/" title="Open Source Initiative"><img src="/files/garland_logo.png" alt="Open Source Initiative" id="logo" /><span>Open Source Initiative</span></a></h1>        </div>

                                                    
      </div> <!-- /header -->

              <div id="sidebar-left" class="sidebar">
          <div class="block block-theme"><form action="/licenses/cddl1.php"  accept-charset="UTF-8" method="post" id="search-theme-form">
<div><div id="search" class="container-inline">
  <div class="form-item" id="edit-search-theme-form-1-wrapper">
 <label for="edit-search-theme-form-1">Search this site: </label>
 <input type="text" maxlength="128" name="search_theme_form" id="edit-search-theme-form-1" size="15" value="" title="Enter the terms you wish to search for." class="form-text" />
</div>
<input type="submit" name="op" id="edit-submit-2" value="Search"  class="form-submit" />
<input type="hidden" name="form_build_id" id="form-acb389bcd419e645ec11727935cffab3" value="form-acb389bcd419e645ec11727935cffab3"  />
<input type="hidden" name="form_id" id="edit-search-theme-form" value="search_theme_form"  />
</div>

</div></form>
</div>          <div id="block-user-1" class="clear-block block block-user">

  <h2>Navigation</h2>

  <div class="content"><ul class="menu"><li class="collapsed first"><a href="/about" title="About the Open Source Initiative">About the OSI</a></li>
<li class="collapsed"><a href="/docs/osd" title="The actual OSD defining what constitutes an Open Source licence">The Open Source Definition</a></li>
<li class="collapsed"><a href="/licenses/index.html">Open Source Licenses</a></li>
<li class="collapsed"><a href="/osr-intro" title="Open Standards Requirement for Software">Open Standards</a></li>
<li class="leaf"><a href="/osi-open-source-education" title="OSI&#039;s Open Source Education Initiative and Activities">Open Source Education</a></li>
<li class="collapsed"><a href="/lists" title="The virtual committees where the OSI&#039;s work gets done">Mailing lists</a></li>
<li class="collapsed"><a href="/help" title="Resources for questions and further exploration">Getting Help</a></li>
<li class="collapsed"><a href="/donate" title="The OSI is a 501(c)3.  Donations are tax-deductible on US income taxes.">Donate to the OSI</a></li>
<li class="leaf last"><a href="/ToS" title="Rules for posting content on this site">Terms of Service</a></li>
</ul></div>
</div>
<div id="block-block-2" class="clear-block block block-block">


  <div class="content"><ul>
<li class="leaf">OSI Board <a href="mailto:osi@opensource.org">email</a></li>
<li class="leaf">Site Admin <a href="mailto:webmaster@opensource.org">email</a></li>
</ul></div>
</div>
        </div>
      
      <div id="center"><div id="squeeze"><div class="right-corner"><div class="left-corner">
          <div class="breadcrumb"><a href="/">Home</a></div>                              <h2>Open Source Initiative OSI - Common Development and Distribution License (CDDL-1.0)</h2>                                                  <div class="clear-block">
            <div id="node-47" class="node">



  
  <div class="content clear-block">
        <img style="float: right; margin: 1em;" width="100" height="137" alt="[OSI Approved License]" src="/trademarks/opensource/OSI-Approved-License-100x137.png"/>
        <center>
<h3>COMMON DEVELOPMENT AND DISTRIBUTION LICENSE
	Version 1.0 (CDDL-1.0)</h3> 
</center>(<a href="cddl1.txt">text</a>)
    <ul>
      <li><p><b>1. Definitions.</b></p>
	<ul>

	  <li><p> <b>1.1. Contributor</b> means each
	  individual or entity that creates or contributes to the creation of
	  Modifications.</p>

	    
	  </li><li><p> <b>1.2. Contributor Version</b> means
	  the combination of the Original Software, prior
	  Modifications used by a Contributor (if any), and the
	  Modifications made by that particular Contributor.</p>

	  </li><li><p> <b>1.3. Covered Software</b> means (a)
	  the Original Software, or (b) Modifications, or (c) the
	  combination of files containing Original Software with files
	  containing Modifications, in each case including portions
	  thereof.</p>

	  </li><li><p> <b>1.4. Executable</b> means the
	  Covered Software in any form other than Source Code.</p>

	  </li><li><p> <b>1.5. Initial Developer</b> means
	  the individual or entity that first makes Original Software
	  available under this License.</p>

	  </li><li><p> <b>1.6. Larger Work</b> means a work
	  which combines Covered Software or portions thereof with
	  code not governed by the terms of this License.</p>

	  </li><li><p> <b>1.7. License</b> means this
	  document.</p>

	  </li><li><p> <b>1.8. Licensable</b> means having
	  the right to grant, to the maximum extent possible, whether
	  at the time of the initial grant or subsequently acquired,
	  any and all of the rights conveyed herein.</p>

	  </li><li><p> <b>1.9. Modifications</b> means the
	  Source Code and Executable form of any of the following:</p>
	    <ul>

	      <li><p><b>A.</b> Any file that results from an addition
	      to, deletion from or modification of the contents of a
	      file containing Original Software or previous
	      Modifications;</p>

	      </li><li><p><b>B.</b> Any new file that contains any part of
	      the Original Software or previous Modification; or</p>

	      </li><li><p><b>C.</b> Any new file that is contributed or
	      otherwise made available under the terms of this
	      License.</p>

	    </li></ul>

	  </li><li><p> <b>1.10. Original Software</b> means
	  the Source Code and Executable form of computer software
	  code that is originally released under this License.</p>

	  </li><li><p> <b>1.11. Patent Claims</b> means any
	  patent claim(s), now owned or hereafter acquired, including
	  without limitation, method, process, and apparatus claims,
	  in any patent Licensable by grantor.</p>

	  </li><li><p> <b>1.12. Source Code</b> means (a) the
	  common form of computer software code in which modifications
	  are made and (b) associated documentation included in or
	  with such code.</p>

	  </li><li><p> <b>1.13. You (or
	  Your)</b> means an individual or a legal
	  entity exercising rights under, and complying with all of
	  the terms of, this License.  For legal entities,
	  You includes any entity which controls, is
	  controlled by, or is under common control with You.  For
	  purposes of this definition, control means
	  (a)&nbsp;the power, direct or indirect, to cause the
	  direction or management of such entity, whether by contract
	  or otherwise, or (b)&nbsp;ownership of more than fifty
	  percent (50%) of the outstanding shares or beneficial
	  ownership of such entity.</p>
	</li></ul>

      </li><li><p><b>2. License Grants.</b></p>
	<ul>
	  <li><p> <b>2.1. The Initial Developer Grant.</b></p>

	    <p> Conditioned upon Your compliance with Section 3.1
	    below and subject to third party intellectual property
	    claims, the Initial Developer hereby grants You a
	    world-wide, royalty-free, non-exclusive license:</p>

	    <ul>

	      <li><p><b>(a)</b> under intellectual property rights
	      (other than patent or trademark) Licensable by Initial
	      Developer, to use, reproduce, modify, display, perform,
	      sublicense and distribute the Original Software (or
	      portions thereof), with or without Modifications, and/or
	      as part of a Larger Work; and</p>

	      </li><li><p><b>(b)</b> under Patent Claims infringed by the
	      making, using or selling of Original Software, to make,
	      have made, use, practice, sell, and offer for sale,
	      and/or otherwise dispose of the Original Software (or
	      portions thereof).</p>

	      </li><li><p><b>(c)</b> The licenses granted in
	      Sections&nbsp;2.1(a) and (b) are effective on the date
	      Initial Developer first distributes or otherwise makes
	      the Original Software available to a third party under
	      the terms of this License.</p>

	      </li><li><p><b>(d)</b> Notwithstanding Section&nbsp;2.1(b)
	      above, no patent license is granted: (1)&nbsp;for code
	      that You delete from the Original Software, or
	      (2)&nbsp;for infringements caused by: (i)&nbsp;the
	      modification of the Original Software, or (ii)&nbsp;the
	      combination of the Original Software with other software
	      or devices.</p>
	    </li></ul>
	  </li><li><p>
		<b>2.2. Contributor Grant.</b></p>

	    <p>Conditioned upon Your compliance with Section 3.1 below
	    and subject to third party intellectual property claims,
	    each Contributor hereby grants You a world-wide,
	    royalty-free, non-exclusive license:</p>

	    <ul>
	      <li><p><b>(a)</b> under intellectual property rights
	      (other than patent or trademark) Licensable by
	      Contributor to use, reproduce, modify, display, perform,
	      sublicense and distribute the Modifications created by
	      such Contributor (or portions thereof), either on an
	      unmodified basis, with other Modifications, as Covered
	      Software and/or as part of a Larger Work; and</p>

	      </li><li><p><b>(b)</b> under Patent Claims infringed by the
	      making, using, or selling of Modifications made by that
	      Contributor either alone and/or in combination with its
	      Contributor Version (or portions of such combination),
	      to make, use, sell, offer for sale, have made, and/or
	      otherwise dispose of: (1)&nbsp;Modifications made by
	      that Contributor (or portions thereof); and (2)&nbsp;the
	      combination of Modifications made by that Contributor
	      with its Contributor Version (or portions of such
	      combination).</p>

	      </li><li><p><b>(c)</b> The licenses granted in
	      Sections&nbsp;2.2(a) and 2.2(b) are effective on the
	      date Contributor first distributes or otherwise makes
	      the Modifications available to a third party.</p>

	      </li><li><p><b>(d)</b> Notwithstanding Section&nbsp;2.2(b)
	      above, no patent license is granted: (1)&nbsp;for any
	      code that Contributor has deleted from the Contributor
	      Version; (2)&nbsp;for infringements caused by:
	      (i)&nbsp;third party modifications of Contributor
	      Version, or (ii)&nbsp;the combination of Modifications
	      made by that Contributor with other software (except as
	      part of the Contributor Version) or other devices; or
	      (3)&nbsp;under Patent Claims infringed by Covered
	      Software in the absence of Modifications made by that
	      Contributor.</p>

	    </li></ul>
	</li></ul>

      </li><li><p><b>3. Distribution Obligations.</b></p>
	<ul>

	  <li><p> <b>3.1. Availability of Source Code.</b></p>

	    <p>Any Covered Software that You distribute or otherwise
	    make available in Executable form must also be made
	    available in Source Code form and that Source Code form
	    must be distributed only under the terms of this License.
	    You must include a copy of this License with every copy of
	    the Source Code form of the Covered Software You
	    distribute or otherwise make available.  You must inform
	    recipients of any such Covered Software in Executable form
	    as to how they can obtain such Covered Software in Source
	    Code form in a reasonable manner on or through a medium
	    customarily used for software exchange.</p>

	  </li><li><p> <b>3.2. Modifications.</b></p>

	    <p>The Modifications that You create or to which You
	    contribute are governed by the terms of this License.  You
	    represent that You believe Your Modifications are Your
	    original creation(s) and/or You have sufficient rights to
	    grant the rights conveyed by this License.</p>

	  </li><li><p> <b>3.3. Required Notices.</b></p>

	    <p>You must include a notice in each of Your Modifications
	    that identifies You as the Contributor of the
	    Modification.  You may not remove or alter any copyright,
	    patent or trademark notices contained within the Covered
	    Software, or any notices of licensing or any descriptive
	    text giving attribution to any Contributor or the Initial
	    Developer.</p>

	  </li><li><p> <b>3.4. Application of Additional Terms.</b></p>

	    <p>You may not offer or impose any terms on any Covered
	    Software in Source Code form that alters or restricts the
	    applicable version of this License or the
	    recipients rights hereunder.  You may choose to
	    offer, and to charge a fee for, warranty, support,
	    indemnity or liability obligations to one or more
	    recipients of Covered Software.  However, you may do so
	    only on Your own behalf, and not on behalf of the Initial
	    Developer or any Contributor.  You must make it absolutely
	    clear that any such warranty, support, indemnity or
	    liability obligation is offered by You alone, and You
	    hereby agree to indemnify the Initial Developer and every
	    Contributor for any liability incurred by the Initial
	    Developer or such Contributor as a result of warranty,
	    support, indemnity or liability terms You offer.</p>

	  </li><li><p> <b>3.5. Distribution of Executable Versions.</b></p>

	    <p>You may distribute the Executable form of the Covered
	    Software under the terms of this License or under the
	    terms of a license of Your choice, which may contain terms
	    different from this License, provided that You are in
	    compliance with the terms of this License and that the
	    license for the Executable form does not attempt to limit
	    or alter the recipients rights in the Source Code
	    form from the rights set forth in this License.  If You
	    distribute the Covered Software in Executable form under a
	    different license, You must make it absolutely clear that
	    any terms which differ from this License are offered by
	    You alone, not by the Initial Developer or Contributor.
	    You hereby agree to indemnify the Initial Developer and
	    every Contributor for any liability incurred by the
	    Initial Developer or such Contributor as a result of any
	    such terms You offer.</p>

	  </li><li><p> <b>3.6. Larger Works.</b></p>

	    <p>You may create a Larger Work by combining Covered
	    Software with other code not governed by the terms of this
	    License and distribute the Larger Work as a single
	    product.  In such a case, You must make sure the
	    requirements of this License are fulfilled for the Covered
	    Software.</p>
	</li></ul>

      </li><li><p><b>4. Versions of the License.</b></p>
	<ul>

	  <li><p>
	      <b>4.1. New Versions.</b></p>

	    <p>Sun Microsystems, Inc. is the initial license steward
	    and may publish revised and/or new versions of this
	    License from time to time.  Each version will be given a
	    distinguishing version number.  Except as provided in
	    Section 4.3, no one other than the license steward has the
	    right to modify this License.</p>

	  </li><li><p>
	      <b>4.2. Effect of New Versions.</b></p>

	    <p>You may always continue to use, distribute or otherwise
	    make the Covered Software available under the terms of the
	    version of the License under which You originally received
	    the Covered Software.  If the Initial Developer includes a
	    notice in the Original Software prohibiting it from being
	    distributed or otherwise made available under any
	    subsequent version of the License, You must distribute and
	    make the Covered Software available under the terms of the
	    version of the License under which You originally received
	    the Covered Software.  Otherwise, You may also choose to
	    use, distribute or otherwise make the Covered Software
	    available under the terms of any subsequent version of the
	    License published by the license steward.</p>

	  </li><li><p>
	    <b>4.3. Modified Versions.</b></p>

	    <p>When You are an Initial Developer and You want to
	    create a new license for Your Original Software, You may
	    create and use a modified version of this License if You:
	    (a)&nbsp;rename the license and remove any references to
	    the name of the license steward (except to note that the
	    license differs from this License); and (b)&nbsp;otherwise
	    make it clear that the license contains terms which differ
	    from this License.</p>
	</li></ul>

      </li><li><p>

	<b>5. DISCLAIMER OF WARRANTY.</b></p>

	<p>COVERED SOFTWARE IS PROVIDED UNDER THIS LICENSE ON AN
	AS IS BASIS, WITHOUT WARRANTY OF ANY KIND,
	EITHER EXPRESSED OR IMPLIED, INCLUDING, WITHOUT LIMITATION,
	WARRANTIES THAT THE COVERED SOFTWARE IS FREE OF DEFECTS,
	MERCHANTABLE, FIT FOR A PARTICULAR PURPOSE OR NON-INFRINGING.
	THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE
	COVERED SOFTWARE IS WITH YOU.  SHOULD ANY COVERED SOFTWARE
	PROVE DEFECTIVE IN ANY RESPECT, YOU (NOT THE INITIAL DEVELOPER
	OR ANY OTHER CONTRIBUTOR) ASSUME THE COST OF ANY NECESSARY
	SERVICING, REPAIR OR CORRECTION.  THIS DISCLAIMER OF WARRANTY
	CONSTITUTES AN ESSENTIAL PART OF THIS LICENSE.  NO USE OF ANY
	COVERED SOFTWARE IS AUTHORIZED HEREUNDER EXCEPT UNDER THIS
	DISCLAIMER.</p>

      </li><li><p>
	<b>6. TERMINATION.</b></p>

	<ul>
	  <li><p><b>6.1.</b> This License and the rights granted
	  hereunder will terminate automatically if You fail to comply
	  with terms herein and fail to cure such breach within 30
	  days of becoming aware of the breach.  Provisions which, by
	  their nature, must remain in effect beyond the termination
	  of this License shall survive.</p>

	  </li><li><p><b>6.2.</b>
If You assert a patent infringement claim (excluding declaratory
judgment actions) against Initial Developer or a Contributor (the
Initial Developer or Contributor against whom You assert such claim is
referred to as Participant) alleging that the Participant Software
(meaning the Contributor Version where the Participant is a Contributor
or the Original Software where the Participant is the Initial
Developer) directly or indirectly infringes any patent, then any and
all rights granted directly or indirectly to You by such Participant,
the Initial Developer (if the Initial Developer is not the Participant)
and all Contributors under Sections&nbsp;2.1 and/or 2.2 of this License
shall, upon 60 days notice from Participant terminate prospectively and
automatically at the expiration of such 60 day notice period, unless if
within such 60 day period You withdraw Your claim with respect to the
Participant Software against such Participant either unilaterally or
pursuant to a written agreement with Participant.</p>

	  </li><li><p><b>6.3.</b> In the event of termination under
	  Sections&nbsp;6.1 or 6.2 above, all end user licenses
	  that have been
	  validly granted by You or any distributor hereunder prior to
	  termination (excluding licenses granted to You by any
	  distributor) shall survive termination.</p>

	</li></ul>

      </li><li><p>
	<b>7. LIMITATION OF LIABILITY.</b></p>

	<p>UNDER NO CIRCUMSTANCES AND UNDER NO LEGAL THEORY, WHETHER
	TORT (INCLUDING NEGLIGENCE), CONTRACT, OR OTHERWISE, SHALL
	YOU, THE INITIAL DEVELOPER, ANY OTHER CONTRIBUTOR, OR ANY
	DISTRIBUTOR OF COVERED SOFTWARE, OR ANY SUPPLIER OF ANY OF
	SUCH PARTIES, BE LIABLE TO ANY PERSON FOR ANY INDIRECT,
	SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES OF ANY CHARACTER
	INCLUDING, WITHOUT LIMITATION, DAMAGES FOR LOST PROFITS, LOSS OF GOODWILL,
	WORK STOPPAGE, COMPUTER FAILURE OR MALFUNCTION, OR ANY AND ALL
	OTHER COMMERCIAL DAMAGES OR LOSSES, EVEN IF SUCH PARTY SHALL
	HAVE BEEN INFORMED OF THE POSSIBILITY OF SUCH DAMAGES.  THIS
	LIMITATION OF LIABILITY SHALL NOT APPLY TO LIABILITY FOR DEATH
	OR PERSONAL INJURY RESULTING FROM SUCH PARTYS
	NEGLIGENCE TO THE EXTENT APPLICABLE LAW PROHIBITS SUCH
	LIMITATION.  SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR
	LIMITATION OF INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THIS
	EXCLUSION AND LIMITATION MAY NOT APPLY TO YOU.</p>

      </li><li><p>
	<b>8. U.S. GOVERNMENT END USERS.</b></p>

	<p>The Covered Software is a commercial item, as
	that term is defined in 48&nbsp;C.F.R.&nbsp;2.101 (Oct. 1995),
	consisting of commercial computer software (as
	that term is defined at 48
	C.F.R. &nbsp;252.227-7014(a)(1)) and commercial
	computer software documentation as such terms are used
	in 48&nbsp;C.F.R.&nbsp;12.212 (Sept. 1995).  Consistent with
	48 C.F.R.  12.212 and 48 C.F.R. 227.7202-1 through 227.7202-4
	(June 1995), all U.S. Government End Users acquire Covered
	Software with only those rights set forth herein.  This
	U.S. Government Rights clause is in lieu of, and supersedes,
	any other FAR, DFAR, or other clause or provision that
	addresses Government rights in computer software under this
	License.</p>

      </li><li><p>
	<b>9. MISCELLANEOUS.</b></p>

	<p>This License represents the complete agreement concerning
	subject matter hereof.  If any provision of this License is
	held to be unenforceable, such provision shall be reformed
	only to the extent necessary to make it enforceable.  This
	License shall be governed by the law of the jurisdiction
	specified in a notice contained within the Original Software
	(except to the extent applicable law, if any, provides
	otherwise), excluding such jurisdictions
	conflict-of-law provisions.  Any
	litigation relating to this License shall be subject to the
	jurisdiction of the courts located in the
	jurisdiction and venue specified in a notice contained within
	the Original Software, with the losing party responsible for
	costs, including, without limitation, court costs and
	reasonable attorneys fees and expenses.  The
	application of the United Nations Convention on Contracts for
	the International Sale of Goods is expressly excluded.  Any
	law or regulation which provides that the language of a
	contract shall be construed against the drafter shall not
	apply to this License.  You agree that You alone are
	responsible for compliance with the United States export
	administration regulations (and the export control laws and
	regulation of any other countries) when You use, distribute or
	otherwise make available any Covered Software.</p>

	</li><li><p>
	  <b>10. RESPONSIBILITY FOR CLAIMS.</b></p>

	<p>As between Initial Developer and the Contributors, each
	party is responsible for claims and damages arising, directly
	or indirectly, out of its utilization of rights under this
	License and You agree to work with Initial Developer and
	Contributors to distribute such responsibility on an equitable
	basis.  Nothing herein is intended or shall be deemed to
	constitute any admission of liability.</p>

    </li></ul>




  </div>

  <div class="clear-block">
    <div class="meta">
        </div>

      </div>

</div>
<div id="comments">
  <h2 class="comments">Comments</h2><form action="/licenses/cddl1.php"  accept-charset="UTF-8" method="post" id="comment-controls">
<div><div class="box">

  <h2>Comment viewing options</h2>

  <div class="content"><div class="container-inline"><input type="hidden" name="form_build_id" id="form-c0c20990751dcaf2d34a0d40c160a4c1" value="form-c0c20990751dcaf2d34a0d40c160a4c1"  />
<input type="hidden" name="form_id" id="edit-comment-controls" value="comment_controls"  />
<div class="form-item" id="edit-mode-wrapper">
 <select name="mode" class="form-select" id="edit-mode" ><option value="1">Flat list - collapsed</option><option value="2">Flat list - expanded</option><option value="3">Threaded list - collapsed</option><option value="4" selected="selected">Threaded list - expanded</option></select>
</div>
<div class="form-item" id="edit-order-wrapper">
 <select name="order" class="form-select" id="edit-order" ><option value="1" selected="selected">Date - newest first</option><option value="2">Date - oldest first</option></select>
</div>
<div class="form-item" id="edit-comments-per-page-wrapper">
 <select name="comments_per_page" class="form-select" id="edit-comments-per-page" ><option value="10">10 comments per page</option><option value="30">30 comments per page</option><option value="50" selected="selected">50 comments per page</option><option value="70">70 comments per page</option><option value="90">90 comments per page</option><option value="150">150 comments per page</option><option value="200">200 comments per page</option><option value="250">250 comments per page</option><option value="300">300 comments per page</option></select>
</div>
<input type="submit" name="op" id="edit-submit" value="Save settings"  class="form-submit" />
</div><div class="description">Select your preferred way to display the comments and click "Save settings" to activate your changes.</div></div>
</div>

</div></form>
<a id="comment-983"></a>
<div class="comment comment-published odd">

  <div class="clear-block">
      <span class="submitted">Mon, 2009-04-27 17:03 — Gerrit DeWitt</span>
  
  
  
    <h3><a href="/licenses/cddl1.php#comment-983" class="active">Wording For Sections 2.1b and 2.2b</a></h3>

    <div class="content">
      <p>Using 2.1b as an example:</p>
<p>"under Patent Claims infringed by the making, using, or selling of Original Software, to ..."</p>
<p>Consider changing the text to this (CHANGES CAPITALIZED) to clarify its intent:</p>
<p>"under Patent Claims THAT WOULD, IN THE ABSENCE OR NON-ACCEPTANCE OF THIS LICENSE, BE INFRINGED by the making, using, or selling of Original Software, to ..."</p>
<p>To infringe literally means "to break into" or "to break in."  Frangere means "to break."  The message this license conveys grants a party who accepts it the patent claims.  Specifically which patent claims does it grant?  Well, those that would otherwise be infringed if this license didn't exist or was not accepted by the party.  So the definition of "infringement" breaks down when the license is accepted, because the license specifically allows the party to exercise the claims!</p>
<p>--Gerrit</p>
          </div>
  </div>

  </div>
<form action="/licenses/cddl1.php"  accept-charset="UTF-8" method="post" id="comment-controls-1">
<div><div class="box">

  <h2>Comment viewing options</h2>

  <div class="content"><div class="container-inline"><input type="hidden" name="form_build_id" id="form-faa22daf383e65ce63906a12656a4f3f" value="form-faa22daf383e65ce63906a12656a4f3f"  />
<input type="hidden" name="form_id" id="edit-comment-controls-1" value="comment_controls"  />
<div class="form-item" id="edit-mode-1-wrapper">
 <select name="mode" class="form-select" id="edit-mode-1" ><option value="1">Flat list - collapsed</option><option value="2">Flat list - expanded</option><option value="3">Threaded list - collapsed</option><option value="4" selected="selected">Threaded list - expanded</option></select>
</div>
<div class="form-item" id="edit-order-1-wrapper">
 <select name="order" class="form-select" id="edit-order-1" ><option value="1" selected="selected">Date - newest first</option><option value="2">Date - oldest first</option></select>
</div>
<div class="form-item" id="edit-comments-per-page-1-wrapper">
 <select name="comments_per_page" class="form-select" id="edit-comments-per-page-1" ><option value="10">10 comments per page</option><option value="30">30 comments per page</option><option value="50" selected="selected">50 comments per page</option><option value="70">70 comments per page</option><option value="90">90 comments per page</option><option value="150">150 comments per page</option><option value="200">200 comments per page</option><option value="250">250 comments per page</option><option value="300">300 comments per page</option></select>
</div>
<input type="submit" name="op" id="edit-submit-1" value="Save settings"  class="form-submit" />
</div><div class="description">Select your preferred way to display the comments and click "Save settings" to activate your changes.</div></div>
</div>

</div></form>
</div>
          </div>
                    <div id="footer"><a rel="license" href="http://creativecommons.org/licenses/by/2.5/"><img alt="Creative Commons License" src="http://i.creativecommons.org/l/by/2.5/88x31.png" /></a><br />Opensource.org site content is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by/2.5/">Creative Commons Attribution 2.5  License</a>.
	
		
	
	|  <a href="../ToS">Terms of Service</a><div id="block-block-7" class="clear-block block block-block">


  <div class="content"><script src="http://www.google-analytics.com/urchin.js" type="text/javascript">
</script>
<script type="text/javascript">
_uacct = "UA-3916956-1";
urchinTracker();
</script></div>
</div>
</div>
      </div></div></div></div> <!-- /.left-corner, /.right-corner, /#squeeze, /#center -->

      
    </div> <!-- /container -->
  </div>
<!-- /layout -->

    </body>
</html>
