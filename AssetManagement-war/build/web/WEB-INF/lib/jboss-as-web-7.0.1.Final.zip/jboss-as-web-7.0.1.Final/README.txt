       ______                     ___   _____    _____
      / / __ )____  __________   /   | / ___/   /__  /
 __  / / __  / __ \/ ___/ ___/  / /| | \__ \      / / 
/ /_/ / /_/ / /_/ (__  |__  )  / ___ |___/ /     / /  
\____/_____/\____/____/____/  /_/  |_/____/     /_/   

Welcome to JBoss Application Server 7
http://www.jboss.org/jbossas/

Go to the above link for documentation, and additional downloads.

Also, once JBoss AS7 is started you can go to http://localhost:8080
for additional information.

Important Notes
---------------
JBoss AS now has two distributions:

1. jboss-as-web
   The Java EE Web Profile "certified" web profile disribution 
      (includes Servlet 3.0 + JAX-RS/RestEasy + CDI/Weld + 
       EJB 3 Lite + Bean Validation + JCA + JPA/Hibernate)

2. jboss-as
   The everything distribution. This distribution is not certified. It includes
    all of the specs in 1 but also adds JMS/HornetQ, and JAX-WS/JBoss Web Services


Key Features
------------

* Fast Startup
* Small Footprint
* Modular Design
* Unified Configuration and Management
* OSGi

And of course Java EE!
